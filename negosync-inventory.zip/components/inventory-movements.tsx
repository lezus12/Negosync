"use client"

import type React from "react"

import { useState } from "react"
import { ArrowUp, ArrowDown, Calendar } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import type { Product, Movement } from "@/app/page"

interface InventoryMovementsProps {
  products: Product[]
  movements: Movement[]
  onAddMovement: (movement: Omit<Movement, "id" | "date">) => void
}

export default function InventoryMovements({ products, movements, onAddMovement }: InventoryMovementsProps) {
  const [formData, setFormData] = useState({
    productId: "",
    type: "" as "entrada" | "salida" | "",
    quantity: "",
    reason: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.productId || !formData.type || !formData.quantity || !formData.reason) {
      alert("Por favor completa todos los campos")
      return
    }

    const quantity = Number.parseInt(formData.quantity)
    if (quantity <= 0) {
      alert("La cantidad debe ser mayor a 0")
      return
    }

    // Verificar stock disponible para salidas
    if (formData.type === "salida") {
      const product = products.find((p) => p.id === formData.productId)
      if (product && quantity > product.stock) {
        alert(`No hay suficiente stock. Stock disponible: ${product.stock}`)
        return
      }
    }

    onAddMovement({
      productId: formData.productId,
      type: formData.type,
      quantity,
      reason: formData.reason,
    })

    setFormData({
      productId: "",
      type: "" as "entrada" | "salida" | "",
      quantity: "",
      reason: "",
    })
  }

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const getProductName = (productId: string) => {
    const product = products.find((p) => p.id === productId)
    return product?.name || "Producto no encontrado"
  }

  const sortedMovements = [...movements].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Movimientos de Inventario</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Formulario de movimientos */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Registrar Movimiento</CardTitle>
              <CardDescription>Registra entradas y salidas de productos</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="product">Producto *</Label>
                  <Select value={formData.productId} onValueChange={(value) => handleChange("productId", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona un producto" />
                    </SelectTrigger>
                    <SelectContent>
                      {products.map((product) => (
                        <SelectItem key={product.id} value={product.id}>
                          {product.name} (Stock: {product.stock})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type">Tipo de Movimiento *</Label>
                  <Select value={formData.type} onValueChange={(value) => handleChange("type", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona el tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="entrada">Entrada (Agregar stock)</SelectItem>
                      <SelectItem value="salida">Salida (Reducir stock)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="quantity">Cantidad *</Label>
                  <Input
                    id="quantity"
                    type="number"
                    min="1"
                    value={formData.quantity}
                    onChange={(e) => handleChange("quantity", e.target.value)}
                    placeholder="0"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reason">Motivo *</Label>
                  <Textarea
                    id="reason"
                    value={formData.reason}
                    onChange={(e) => handleChange("reason", e.target.value)}
                    placeholder="Ej: Compra a proveedor, Venta, Producto vencido, etc."
                    required
                  />
                </div>

                <Button type="submit" className="w-full">
                  Registrar Movimiento
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Lista de movimientos */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Historial de Movimientos</CardTitle>
              <CardDescription>{movements.length} movimiento(s) registrado(s)</CardDescription>
            </CardHeader>
            <CardContent>
              {sortedMovements.length === 0 ? (
                <div className="text-center py-8">
                  <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No hay movimientos registrados</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {sortedMovements.map((movement) => (
                    <div key={movement.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div
                          className={`p-2 rounded-full ${movement.type === "entrada" ? "bg-green-100" : "bg-red-100"}`}
                        >
                          {movement.type === "entrada" ? (
                            <ArrowUp className="h-4 w-4 text-green-600" />
                          ) : (
                            <ArrowDown className="h-4 w-4 text-red-600" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{getProductName(movement.productId)}</p>
                          <p className="text-sm text-gray-600">{movement.reason}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(movement.date).toLocaleDateString("es-ES", {
                              year: "numeric",
                              month: "short",
                              day: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={movement.type === "entrada" ? "default" : "secondary"}>
                          {movement.type === "entrada" ? "+" : "-"}
                          {movement.quantity}
                        </Badge>
                        <p className="text-xs text-gray-500 mt-1 capitalize">{movement.type}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
