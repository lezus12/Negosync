"use client"

import { useState } from "react"
import { Edit, Trash2, Package } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import ProductForm from "./product-form"
import type { Product } from "@/app/page"

interface ProductListProps {
  products: Product[]
  onUpdate: (id: string, product: Omit<Product, "id" | "createdAt">) => void
  onDelete: (id: string) => void
}

export default function ProductList({ products, onUpdate, onDelete }: ProductListProps) {
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)

  const handleEdit = (product: Product) => {
    setEditingProduct(product)
    setIsEditDialogOpen(true)
  }

  const handleUpdate = (updatedProduct: Omit<Product, "id" | "createdAt">) => {
    if (editingProduct) {
      onUpdate(editingProduct.id, updatedProduct)
      setIsEditDialogOpen(false)
      setEditingProduct(null)
    }
  }

  const getStockStatus = (product: Product) => {
    if (product.stock === 0) return { label: "Sin Stock", variant: "destructive" as const }
    if (product.stock <= product.minStock) return { label: "Stock Bajo", variant: "secondary" as const }
    return { label: "En Stock", variant: "default" as const }
  }

  if (products.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Package className="h-12 w-12 text-gray-400 mb-4" />
          <p className="text-gray-500 text-center">
            No hay productos registrados.
            <br />
            Agrega tu primer producto usando el formulario.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Lista de Productos</CardTitle>
        <CardDescription>{products.length} producto(s) registrado(s)</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {products.map((product) => {
            const stockStatus = getStockStatus(product)
            return (
              <div
                key={product.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-semibold">{product.name}</h3>
                    <Badge variant={stockStatus.variant}>{stockStatus.label}</Badge>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm text-gray-600">
                    <span>
                      <strong>Categoría:</strong> {product.category}
                    </span>
                    <span>
                      <strong>Precio:</strong> ${product.price.toFixed(2)}
                    </span>
                    <span>
                      <strong>Stock:</strong> {product.stock}
                    </span>
                    <span>
                      <strong>Proveedor:</strong> {product.supplier}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2 ml-4">
                  <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => handleEdit(product)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md">
                      <DialogHeader>
                        <DialogTitle>Editar Producto</DialogTitle>
                      </DialogHeader>
                      {editingProduct && (
                        <ProductForm
                          initialData={editingProduct}
                          onSubmit={handleUpdate}
                          onCancel={() => {
                            setIsEditDialogOpen(false)
                            setEditingProduct(null)
                          }}
                        />
                      )}
                    </DialogContent>
                  </Dialog>

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>¿Eliminar producto?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Esta acción no se puede deshacer. Se eliminará permanentemente el producto "{product.name}" y
                          todos sus movimientos de inventario.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={() => onDelete(product.id)}>Eliminar</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
