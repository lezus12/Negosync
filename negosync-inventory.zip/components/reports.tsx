"use client"

import { BarChart3, TrendingDown, Package, Calendar } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Product, Movement } from "@/app/page"

interface ReportsProps {
  products: Product[]
  movements: Movement[]
}

export default function Reports({ products, movements }: ReportsProps) {
  // Productos más vendidos (basado en salidas)
  const getTopSellingProducts = () => {
    const salesMap = new Map<string, number>()

    movements
      .filter((m) => m.type === "salida")
      .forEach((movement) => {
        const current = salesMap.get(movement.productId) || 0
        salesMap.set(movement.productId, current + movement.quantity)
      })

    return Array.from(salesMap.entries())
      .map(([productId, quantity]) => {
        const product = products.find((p) => p.id === productId)
        return product ? { product, quantity } : null
      })
      .filter(Boolean)
      .sort((a, b) => b!.quantity - a!.quantity)
      .slice(0, 5)
  }

  // Productos con stock bajo
  const getLowStockProducts = () => {
    return products.filter((p) => p.stock <= p.minStock).sort((a, b) => a.stock / a.minStock - b.stock / b.minStock)
  }

  // Productos por categoría
  const getProductsByCategory = () => {
    const categoryMap = new Map<string, number>()

    products.forEach((product) => {
      const current = categoryMap.get(product.category) || 0
      categoryMap.set(product.category, current + 1)
    })

    return Array.from(categoryMap.entries())
      .map(([category, count]) => ({ category, count }))
      .sort((a, b) => b.count - a.count)
  }

  // Valor por categoría
  const getValueByCategory = () => {
    const categoryMap = new Map<string, number>()

    products.forEach((product) => {
      const current = categoryMap.get(product.category) || 0
      categoryMap.set(product.category, current + product.price * product.stock)
    })

    return Array.from(categoryMap.entries())
      .map(([category, value]) => ({ category, value }))
      .sort((a, b) => b.value - a.value)
  }

  // Movimientos recientes
  const getRecentMovements = () => {
    return movements.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 10)
  }

  const topSellingProducts = getTopSellingProducts()
  const lowStockProducts = getLowStockProducts()
  const productsByCategory = getProductsByCategory()
  const valueByCategory = getValueByCategory()
  const recentMovements = getRecentMovements()

  const getProductName = (productId: string) => {
    const product = products.find((p) => p.id === productId)
    return product?.name || "Producto no encontrado"
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Reportes</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Productos más vendidos */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Productos Más Vendidos
            </CardTitle>
            <CardDescription>Basado en las salidas registradas</CardDescription>
          </CardHeader>
          <CardContent>
            {topSellingProducts.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No hay datos de ventas</p>
            ) : (
              <div className="space-y-3">
                {topSellingProducts.map((item, index) => (
                  <div key={item!.product.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium">{item!.product.name}</p>
                        <p className="text-sm text-gray-600">{item!.product.category}</p>
                      </div>
                    </div>
                    <Badge variant="secondary">{item!.quantity} vendidos</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Productos con stock bajo */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5" />
              Productos con Stock Bajo
            </CardTitle>
            <CardDescription>Productos que necesitan reposición</CardDescription>
          </CardHeader>
          <CardContent>
            {lowStockProducts.length === 0 ? (
              <p className="text-green-600 text-center py-4">¡Todos los productos tienen stock suficiente!</p>
            ) : (
              <div className="space-y-3">
                {lowStockProducts.map((product) => (
                  <div key={product.id} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-gray-600">{product.category}</p>
                    </div>
                    <div className="text-right">
                      <Badge variant={product.stock === 0 ? "destructive" : "secondary"}>
                        {product.stock} / {product.minStock}
                      </Badge>
                      <p className="text-xs text-gray-500 mt-1">{product.stock === 0 ? "Sin stock" : "Stock bajo"}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Productos por categoría */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Productos por Categoría
            </CardTitle>
            <CardDescription>Distribución de productos</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {productsByCategory.map((item) => (
                <div key={item.category} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <p className="font-medium">{item.category}</p>
                  <Badge variant="outline">
                    {item.count} producto{item.count !== 1 ? "s" : ""}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Valor por categoría */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Valor por Categoría
            </CardTitle>
            <CardDescription>Valor total del inventario por categoría</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {valueByCategory.map((item) => (
                <div key={item.category} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <p className="font-medium">{item.category}</p>
                  <Badge variant="outline">${item.value.toFixed(2)}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Movimientos recientes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Movimientos Recientes
          </CardTitle>
          <CardDescription>Últimos 10 movimientos de inventario</CardDescription>
        </CardHeader>
        <CardContent>
          {recentMovements.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No hay movimientos registrados</p>
          ) : (
            <div className="space-y-3">
              {recentMovements.map((movement) => (
                <div key={movement.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">{getProductName(movement.productId)}</p>
                    <p className="text-sm text-gray-600">{movement.reason}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(movement.date).toLocaleDateString("es-ES", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <Badge variant={movement.type === "entrada" ? "default" : "secondary"}>
                    {movement.type === "entrada" ? "+" : "-"}
                    {movement.quantity}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
