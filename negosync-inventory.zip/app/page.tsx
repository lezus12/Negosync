"use client"

import { useState, useEffect } from "react"
import { Package, ShoppingCart, AlertTriangle, TrendingUp, Search, FileText } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import ProductForm from "@/components/product-form"
import ProductList from "@/components/product-list"
import InventoryMovements from "@/components/inventory-movements"
import Reports from "@/components/reports"

export interface Product {
  id: string
  name: string
  category: string
  price: number
  stock: number
  minStock: number
  supplier: string
  createdAt: Date
}

export interface Movement {
  id: string
  productId: string
  type: "entrada" | "salida"
  quantity: number
  reason: string
  date: Date
}

export default function NegoSync() {
  const [products, setProducts] = useState<Product[]>([])
  const [movements, setMovements] = useState<Movement[]>([])
  const [activeTab, setActiveTab] = useState("dashboard")
  const [searchTerm, setSearchTerm] = useState("")

  // Datos de ejemplo
  useEffect(() => {
    const sampleProducts: Product[] = [
      {
        id: "1",
        name: "Coca Cola 500ml",
        category: "Bebidas",
        price: 2.5,
        stock: 45,
        minStock: 10,
        supplier: "Distribuidora Central",
        createdAt: new Date("2024-01-15"),
      },
      {
        id: "2",
        name: "Pan Integral",
        category: "Panadería",
        price: 1.8,
        stock: 8,
        minStock: 15,
        supplier: "Panadería San José",
        createdAt: new Date("2024-01-16"),
      },
      {
        id: "3",
        name: "Leche Entera 1L",
        category: "Lácteos",
        price: 3.2,
        stock: 25,
        minStock: 12,
        supplier: "Lácteos del Valle",
        createdAt: new Date("2024-01-17"),
      },
      {
        id: "4",
        name: "Arroz 1kg",
        category: "Granos",
        price: 4.5,
        stock: 5,
        minStock: 20,
        supplier: "Granos del Norte",
        createdAt: new Date("2024-01-18"),
      },
    ]

    const sampleMovements: Movement[] = [
      {
        id: "1",
        productId: "1",
        type: "entrada",
        quantity: 50,
        reason: "Compra inicial",
        date: new Date("2024-01-15"),
      },
      {
        id: "2",
        productId: "1",
        type: "salida",
        quantity: 5,
        reason: "Venta",
        date: new Date("2024-01-16"),
      },
    ]

    setProducts(sampleProducts)
    setMovements(sampleMovements)
  }, [])

  const addProduct = (product: Omit<Product, "id" | "createdAt">) => {
    const newProduct: Product = {
      ...product,
      id: Date.now().toString(),
      createdAt: new Date(),
    }
    setProducts([...products, newProduct])
  }

  const updateProduct = (id: string, updatedProduct: Omit<Product, "id" | "createdAt">) => {
    setProducts(products.map((p) => (p.id === id ? { ...p, ...updatedProduct } : p)))
  }

  const deleteProduct = (id: string) => {
    setProducts(products.filter((p) => p.id !== id))
    setMovements(movements.filter((m) => m.productId !== id))
  }

  const addMovement = (movement: Omit<Movement, "id" | "date">) => {
    const newMovement: Movement = {
      ...movement,
      id: Date.now().toString(),
      date: new Date(),
    }

    // Actualizar stock del producto
    setProducts(
      products.map((p) => {
        if (p.id === movement.productId) {
          const newStock = movement.type === "entrada" ? p.stock + movement.quantity : p.stock - movement.quantity
          return { ...p, stock: Math.max(0, newStock) }
        }
        return p
      }),
    )

    setMovements([...movements, newMovement])
  }

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.supplier.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const lowStockProducts = products.filter((p) => p.stock <= p.minStock)
  const totalProducts = products.length
  const totalValue = products.reduce((sum, p) => sum + p.price * p.stock, 0)
  const outOfStock = products.filter((p) => p.stock === 0).length

  const menuItems = [
    { id: "dashboard", label: "Panel Principal", icon: Package },
    { id: "products", label: "Productos", icon: ShoppingCart },
    { id: "movements", label: "Movimientos", icon: TrendingUp },
    { id: "reports", label: "Reportes", icon: FileText },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Package className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">NegoSync</h1>
                <p className="text-sm text-gray-500">Sistema de Control de Inventario</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar productos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation */}
        <nav className="mb-8">
          <div className="flex space-x-1 bg-white p-1 rounded-lg shadow-sm">
            {menuItems.map((item) => {
              const Icon = item.icon
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === item.id
                      ? "bg-blue-600 text-white"
                      : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </button>
              )
            })}
          </div>
        </nav>

        {/* Alertas de Stock Bajo */}
        {lowStockProducts.length > 0 && (
          <Alert className="mb-6 border-orange-200 bg-orange-50">
            <AlertTriangle className="h-4 w-4 text-orange-600" />
            <AlertDescription className="text-orange-800">
              <strong>¡Atención!</strong> {lowStockProducts.length} producto(s) con stock bajo:{" "}
              {lowStockProducts.map((p) => p.name).join(", ")}
            </AlertDescription>
          </Alert>
        )}

        {/* Content */}
        {activeTab === "dashboard" && (
          <div className="space-y-6">
            {/* Métricas principales */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Productos</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalProducts}</div>
                  <p className="text-xs text-muted-foreground">productos registrados</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Valor Total</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${totalValue.toFixed(2)}</div>
                  <p className="text-xs text-muted-foreground">valor del inventario</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Stock Bajo</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-600">{lowStockProducts.length}</div>
                  <p className="text-xs text-muted-foreground">productos con stock bajo</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Sin Stock</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">{outOfStock}</div>
                  <p className="text-xs text-muted-foreground">productos agotados</p>
                </CardContent>
              </Card>
            </div>

            {/* Productos con stock bajo */}
            {lowStockProducts.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Productos con Stock Bajo</CardTitle>
                  <CardDescription>Productos que necesitan reposición urgente</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {lowStockProducts.map((product) => (
                      <div key={product.id} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-gray-600">{product.category}</p>
                        </div>
                        <div className="text-right">
                          <Badge variant={product.stock === 0 ? "destructive" : "secondary"}>
                            Stock: {product.stock}
                          </Badge>
                          <p className="text-xs text-gray-500 mt-1">Mín: {product.minStock}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {activeTab === "products" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Gestión de Productos</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <ProductForm onSubmit={addProduct} />
              </div>
              <div className="lg:col-span-2">
                <ProductList products={filteredProducts} onUpdate={updateProduct} onDelete={deleteProduct} />
              </div>
            </div>
          </div>
        )}

        {activeTab === "movements" && (
          <InventoryMovements products={products} movements={movements} onAddMovement={addMovement} />
        )}

        {activeTab === "reports" && <Reports products={products} movements={movements} />}
      </div>
    </div>
  )
}
